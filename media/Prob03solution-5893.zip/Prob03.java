//34567890123456789012345678901234567890123456789012345678
/*File Prob03 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Dimension;

public class Prob03{
  public static void main(String[] args){
    new Prob03Runner();
  }//end main method
}//end class Prob03
//======================================================//

class Prob03Runner extends JFrame{

  private JPanel controlPanel = new JPanel();
  private JPanel colorPanel = new JPanel();
  private JPanel buttonPanel = new JPanel();
  private JPanel colorIndicatorPanel = new JPanel();

  private JTextField redField = new JTextField("000000");
  private JTextField greenField = 
                                 new JTextField("000000");
  private JTextField blueField = new JTextField("000000");
  
  private int redInt = 0;
  private int greenInt = 0;
  private int blueInt = 0;

  private JButton setColorButton = 
                           new JButton("Set Yellow Color");
  //----------------------------------------------------//

  public Prob03Runner(){//constructor

    setDefaultCloseOperation(
                           WindowConstants.EXIT_ON_CLOSE);

    controlPanel.setLayout(new GridLayout(2,1));
    controlPanel.add(colorPanel);
    controlPanel.add(buttonPanel);

    colorPanel.setBackground(Color.GREEN);
    colorPanel.add(new JLabel("Red = "));
    colorPanel.add(redField);
    colorPanel.add(new JLabel(" Green = "));
    colorPanel.add(greenField);
    colorPanel.add(new JLabel(" Blue = "));
    colorPanel.add(blueField);
    colorPanel.add(colorIndicatorPanel);

    colorIndicatorPanel.setBorder(
                           new LineBorder(Color.black,1));
    colorIndicatorPanel.setPreferredSize(
                                    new Dimension(20,20));

    buttonPanel.setBackground(Color.BLUE);
    buttonPanel.add(setColorButton);
    
    //Color the swatch for the first time.
    paintColorSwatch();

    //Add the controlPanel to the content pane, adjust to
    // the correct size, and set the tiele.
    getContentPane().add(controlPanel);
    pack();
    setTitle("Dick Baldwin");

    //Make the GUI visible
    setVisible(true);

    //--------------------------------------------------//
    //Register listeners on the user input components.
    //--------------------------------------------------//
    setColorButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Set the color to green.
          redInt = 255;
          greenInt = 255;
          blueInt = 0;
          
          //Show the color values in the text fields.
          redField.setText("" + redInt);
          greenField.setText("" + greenInt);
          blueField.setText("" + blueInt);

        }//end action performed
      }//end new ActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a document listener on the red text field.
    // This listener will respond when the contents of
    // the text field are modified either by the program
    // or by the user.
    redField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){
          //Empty method - not needed
        }//end changedUpdate

        public void removeUpdate(DocumentEvent e){
          try{
            redInt = Integer.parseInt(
                                   redField.getText());
            if((redInt >= 0) && (redInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            redInt = Integer.parseInt(
                                   redField.getText());
            if((redInt >= 0) && (redInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//

    //Register a document listener on the green text
    // field. Essentially the same as the above.
    greenField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            greenInt = Integer.parseInt(
                                 greenField.getText());
            if((greenInt >= 0) && (greenInt <= 255))
            {
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            greenInt = Integer.parseInt(
                                 greenField.getText());
            if((greenInt >= 0) && (greenInt <= 255))
            {
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
    
    //Register a document listener on the blue text
    // field. Essentially the same as the above.
    blueField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            blueInt = Integer.parseInt(
                                  blueField.getText());
            if((blueInt >= 0) && (blueInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            blueInt = Integer.parseInt(
                                  blueField.getText());
            if((blueInt >= 0) && (blueInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to color a swatch 
  // located next to the RGB color values.
  private void paintColorSwatch(){
    colorIndicatorPanel.setBackground(
                      new Color(redInt,greenInt,blueInt));
  }//end paintColorSwatch

  //----------------------------------------------------//

}//end class Prob03Runner


//34567890123456789012345678901234567890123456789012345678
