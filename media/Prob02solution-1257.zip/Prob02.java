//34567890123456789012345678901234567890123456789012345678
/*File Prob02 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class Prob02{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob02Runner();
  }//end main method
}//end class Prob02
//End program specifications.
//////////////////////////////////////////////////////////

class Prob02Runner extends JFrame{

  private JPanel mainPanel = new JPanel();
  private JPanel titlePanel = new JPanel();
  private JSlider slider = new JSlider();

  private Picture background = new Picture("Prob02b.jpg");
  private Picture butterfly = new Picture("Prob02a.jpg");


  private int backgroundWidth = background.getWidth();
  private int backgroundHeight = background.getHeight();
  private int butterflyWidth = butterfly.getWidth();
  private int butterflyHeight = butterfly.getHeight();

  private Picture display =
            new Picture(backgroundWidth,backgroundHeight);
  private Picture tempPicture =
              new Picture(butterflyWidth,butterflyHeight);

  private Image image = null;
  private Graphics graphics = null;

  public Prob02Runner(){//constructor
    //Do some initial setup.
    System.out.println("Dick Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    background.addMessage(
                         "Dick Baldwin",10,20);

    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    mainPanel.setLayout(new BorderLayout());
    titlePanel.add(new JLabel(
                         "Percent Opacity of Butterfly"));
    mainPanel.add(titlePanel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    getContentPane().add(mainPanel);
    //pack();
    setSize(backgroundWidth + 7,97);
    setTitle("Dick Baldwin");
    setLocation(0,backgroundHeight + 25);
    setVisible(true);

    //Draw and display the initial image with 50-percent
    // opacity. In order to avoid instantiating and
    // destroying a lot of Picture objects, the
    // procedure is to simply get images from existing
    // picture objects and draw them on other existing
    // picture objects.
    graphics = display.getGraphics();
    graphics.drawImage(background.getImage(),0,0,null);

    //Set the opacity of butterfly and draw it onto the
    // display. In this case, the opacity is set to
    // 50-percent. The image of the butterfly is centered
    // on the background.
    butterfly = setOpacity(butterfly,50);
    drawPictureOnPicture(
                  butterfly,
                  display,
                  backgroundWidth/2 - butterflyWidth/2,
                  backgroundHeight/2 - butterflyHeight/2);
    display.show();
    //--------------------------------------------------//
    //Register an anonymous listener object on the slkder.
    //Each time the slider fires a ChangeEvent, this event
    // handler draws a new background image on the
    // display. This erases what was previously drawn
    // there. Then it uses the current value of the slider
    // to set the opacity of the butterfly image and
    // draws it on the display on top of the background
    // image. It is centered on the background image.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Draw a new copy of the background on the
          // display.
          graphics = display.getGraphics();
          graphics.drawImage(
                          background.getImage(),0,0,null);

          //Set the opacity of butterfly and copy it onto
          // the display. Then repaint the display.
          butterfly =
                  setOpacity(butterfly,slider.getValue());
          drawPictureOnPicture(
                  butterfly,
                  display,
                  backgroundWidth/2 - butterflyWidth/2,
                  backgroundHeight/2 - butterflyHeight/2);
          display.repaint();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//


  //This method copies an incoming picture into an
  // existing temporary picture, setting the alpha value
  // for every pixel to a specified value. Then it returns
  // the modified temporary picture object.
  private Picture setOpacity(
                       Picture pic,double percentOpacity){

    int opacity = (int)(255*percentOpacity/100);
    int opacityMask = opacity << 24;

    for(int col = 0;col < butterflyWidth;col++){
      for(int row = 0;row < butterflyHeight;row++){
        //Get the pixel in basic int format.
        int basicPixel = pic.getBasicPixel(col,row);

        //Set the alpha value for the pixel.
        basicPixel = basicPixel & 0x00FFFFFF;
        basicPixel = basicPixel | opacityMask;

        //Set the modified pixel into tempPicture.
        tempPicture.setBasicPixel(col,row,basicPixel);
      }//end inner loop
    }//end outer loop

    return tempPicture;

  }//end setOpacity
  //----------------------------------------------------//

  //Draws the source picture onto the destination
  // picture with an offset on both axes.
  private void drawPictureOnPicture(
                     Picture source,Picture dest,int xOff,
                                                int yOff){

      Graphics destGraphics = dest.getGraphics();
      Image sourceImage = source.getImage();
      destGraphics.drawImage(sourceImage,
                             xOff,
                             yOff,
                             null);
  }//end drawPictureOnPicture method
}//end class Prob02Runner



//34567890123456789012345678901234567890123456789012345678