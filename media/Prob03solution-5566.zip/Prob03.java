//34567890123456789012345678901234567890123456789012345678
/*File Prob03 Copyright 2012 R.G.Baldwin
*********************************************************/
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.BorderLayout;
import java.awt.Color;

public class Prob03{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob03Runner();
  }//end main method
}//end class Prob03
//End program specifications.
//////////////////////////////////////////////////////////

class Prob03Runner extends JFrame{

  private JPanel mainPanel = new JPanel();
  private JPanel titlePanel = new JPanel();
  private JSlider slider = new JSlider();

  private Picture butterfly = new Picture("Prob03.jpg");

  private int butterflyWidth = butterfly.getWidth();
  private int butterflyHeight = butterfly.getHeight();

  private Picture display =
              new Picture(butterflyWidth,butterflyHeight);

  private Pixel pix1;
  private Pixel pix2;
  private Pixel displayPixel;

  private double distance = 0;

  public Prob03Runner(){//constructor
    System.out.println("Dick Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    butterfly.addMessage("Dick Baldwin",10,15);

    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    mainPanel.setLayout(new BorderLayout());
    titlePanel.add(new JLabel(
                             "Edge Detection Threshold"));
    mainPanel.add(titlePanel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    getContentPane().add(mainPanel);
    //pack();
    setSize(butterflyWidth + 7,97);
    setTitle("Dick Baldwin");
    setLocation(0,butterflyHeight + 25);
    setVisible(true);

    //Produce the initial display with a threshold value
    // of 50, which matches the initial position of the
    // pointer on the slider.
    display = edgeDetector(butterfly,50);

    display.show();
    //--------------------------------------------------//
    //Register an anonymous listener object on the slider.
    //Each time the slider fires a ChangeEvent, this event
    // handler calls the edgeDetector method to get a new
    // edge-detedted image for which the threshold is the
    // current value of the slider. Then the display is
    // repainted showing the new image.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){

          display = edgeDetector(
                             butterfly,slider.getValue());
          display.repaint();

        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//
  /*This method performs edge detection on a Picture
   *object by rows and also by columns.
   *All edges that are detected by processing adjacent
   *pixels on a row are marked in red.
   *All edges that are detected by processing adjacent
   *pixels on a column are marked in black.
   *If a pixel is determined to be on an edge using both
   *approaches, it ends up being black.
   *Pixels that are determined to be on an edge only by
   *processing adjacent pixels on a row end up being red.
  */

  private Picture edgeDetector(
                           Picture picture,int threshold){
    for(int row = 0;row < butterflyHeight - 1;row++){
      for(int col = 0;col < butterflyWidth - 1;col++){
        pix1 = picture.getPixel(col,row);
        displayPixel = display.getPixel(col,row);

        //First process two adjacent pixels on the same
        // row.
        pix2 = picture.getPixel(col + 1,row);

        //Get and save the color distance between the two
        // pixels.
        distance = pix1.colorDistance(pix2.getColor());

        //Compare the color distance to the threshold and
        // set the color of the pixel in the display
        // picture accordingly.
        if(distance > threshold){
          displayPixel.setColor(Color.RED);
        }else{
          displayPixel.setColor(Color.WHITE);
        }//end else

        //Now process two adjacent pixels in the same
        // column using the same approach.
        pix2 = picture.getPixel(col,row + 1);
        distance = pix1.colorDistance(pix2.getColor());
        //Compare the color distance to the threshold and
        // change pixel color accordingly.
        if(distance > threshold){
          displayPixel.setColor(Color.BLACK);
        }//end if

      }//end inner loop
    }//end outer loop

    return display;
  }//end edgeDetector
}//end class Prob03Runner



//34567890123456789012345678901234567890123456789012345678