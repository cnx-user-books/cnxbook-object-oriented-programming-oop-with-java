//34567890123456789012345678901234567890123456789012345678
/*File Prob02 Copyright 2008 R.G.Baldwin*/

import java.awt.Color;

public class Prob02{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    World mars = new World(200,300);
    Turtle joe = new Turtle(mars,"Joe");
    joe.moveTo(20,280);
    joe.setInfoColor(Color.WHITE);
    joe.setShowInfo(true);
    System.out.println(joe);
  }//end main method
}//end class Prob02
//End program specifications.
//////////////////////////////////////////////////////////

//34567890123456789012345678901234567890123456789012345678
