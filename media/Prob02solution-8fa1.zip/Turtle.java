
/*12/23/0812/23/08 This class and the class named
SimpleTurtle were modified to:

Accept and save a String parameter in addition to the
World parameter when the Turtle object is constructed.

Modify the toString method to cause it to return the
value of the String parameter whenever the toString
method is called. This causes the drawInfoString method
to display the string in place of its normal behavior.

Cause the default background of the world to be BLUE.

Cause the student's name to be displayed near the top of
the World image.

Cause the student's name as well as the turtle's name to
be displayed on the command line.
*/

/**
 * Class that represents a turtle which is similar to a Logo turtle.
 * This class inherts from SimpleTurtle and is for students
 * to add methods to.
 *
 * Copyright Georgia Institute of Technology 2004
 * @author Barb Ericson ericson@cc.gatech.edu
 */
public class Turtle extends SimpleTurtle
{
  ////////////////// constructors ///////////////////////

  /** Constructor that takes the x and y and a picture to
   * draw on
   * @param x the starting x position
   * @param y the starting y position
   * @param picture the picture to draw on
   */
  public Turtle (int x, int y, Picture picture)
  {
    // let the parent constructor handle it
    super(x,y,picture);
  }

  /** Constructor that takes the x and y and a model
   * display to draw it on
   * @param x the starting x position
   * @param y the starting y position
   * @param modelDisplayer the thing that displays the model
   */
  public Turtle (int x, int y,
                 ModelDisplay modelDisplayer)
  {
    // let the parent constructor handle it
    super(x,y,modelDisplayer);
  }
  //The following constructor was modified to accept and
  // save a String parameter and pass it to the superclass
  // constructor.
  /** Constructor that takes the model display
   * @param modelDisplay the thing that displays the model
   */
  public Turtle (ModelDisplay modelDisplay,
                 String turtleName){
    // let the parent constructor handle it
    super(modelDisplay,turtleName);
    System.out.println("Dick Baldwin");
  }

  /**
   * Constructor that takes a picture to draw on
   * @param p the picture to draw on
   */
  public Turtle (Picture p)
  {
    // let the parent constructor handle it
    super(p);
  }

  /////////////////// methods ///////////////////////


} // this } is the end of class Turtle, put all new methods before this