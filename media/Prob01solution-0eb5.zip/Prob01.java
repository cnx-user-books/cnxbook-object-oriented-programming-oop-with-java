//34567890123456789012345678901234567890123456789012345678
/*File Prob01 Copyright 2008 R.G.Baldwin
*********************************************************/

public class Prob01{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    World mars = new World(200,250);
    Turtle joe = new Turtle(mars);
    joe.forward();
    Turtle bill = new Turtle(mars);
    bill.moveTo(50,125);
    Turtle sue = new Turtle(mars);
    sue.moveTo(150,125);
    Turtle tom = new Turtle(mars);
    tom.moveTo(100,225);
  }//end main method
}//end class Prob01
//End program specifications.
//////////////////////////////////////////////////////////

//34567890123456789012345678901234567890123456789012345678
