//34567890123456789012345678901234567890123456789012345678
/*File Prob05 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Label;
import java.awt.Button;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

import javax.swing.JFrame;

public class Prob05{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob05Runner();
  }//end main method
}//end class Prob05
//End program specifications.
//////////////////////////////////////////////////////////

class Prob05Runner{
  Turtle turtle = null;
  Picture picture = null;
//  int counter = 0;
  World world = new World(200,300);
  Panel mainPanel = new Panel();
  Label angleLabel = new Label("Enter Angle");
  TextField angleField = new TextField("000");
  Label distanceLabel = new Label("Enter Distance");
  TextField distanceField = new TextField("000");
  Button moveButton = new Button("Move");
  Button quitButton = new Button("Quit");
  int angle = 0;
  int distance = 0;

  public Prob05Runner(){
    System.out.println("Dick Baldwin");

    //Construct the GUI.
    mainPanel.setBackground(Color.ORANGE);
    mainPanel.setLayout(new GridLayout(0,2));
    mainPanel.add(angleLabel);
    mainPanel.add(angleField);
    mainPanel.add(distanceLabel);
    mainPanel.add(distanceField);
    mainPanel.add(moveButton);
    mainPanel.add(quitButton);

    //Get a reference to the world frame and add the GUI
    // to the frame.
    JFrame frame = world.getFrame();
    frame.getContentPane().add(
                            mainPanel,BorderLayout.SOUTH);


    frame.pack();

    //Initialize the picture.
    picture = world.getPicture();
    //Set picture background to BLUE
    picture.setAllPixelsToAColor(Color.BLUE);
    //Display the student's name on the picture.
    picture.addMessage("Dick Baldwin",10,20);
    //Add a turtle to the world. This causes the
    // world to be repainted.
    turtle = new Turtle(world);

    //--------------------------------------------------//
    //Register anonymous listeners on the two buttons.
    moveButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          angle = Integer.parseInt(angleField.getText());
          distance = Integer.parseInt(
                                 distanceField.getText());
          turtle.turn(angle);
          turtle.forward(distance);
        }//end action performed
      }//end newActionListener
    );//end addActionListener

    quitButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          System.exit(0);
        }//end action performed
      }//end newActionListener
    );//end addActionListener

  }//end constructor
  //----------------------------------------------------//

}//end class Prob05Runner
//34567890123456789012345678901234567890123456789012345678
