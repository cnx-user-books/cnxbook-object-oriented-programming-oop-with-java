//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//See Nutshell page 58 for a discussion of
//static initializer blocks

/*File Init01.java
Copyright 2003 R.G.Baldwin

Illustrates the use of static initializer blocks
to execute code that is too complex to be
contained in a simple variable initializer.

Demonstrates that static initializer blocks are
executed in the order in which they appear in the
class definition.

Demonstrates that other code can be inserted
between static initializer blocks in a class
definition.

The output will change each time this program is
run.  The output for one run is shown below. Line
breaks were manually inserted to force the
material to fit in this narrow publication 
format.

Start load: Fri May 30 15:28:49 CDT 2003
End first static init: 
                     Fri May 30 15:28:49 CDT 2003
End second static init: 
                     Fri May 30 15:28:54 CDT 2003
End load: Fri May 30 15:28:54 CDT 2003
var3 initialized: Fri May 30 15:28:49 CDT 2003
var3 = 54
var4 initialized: Fri May 30 15:28:54 CDT 2003
var4 = 5008 msec
Obj instantiated: Fri May 30 15:28:59 CDT 2003

Note the five-secod time intervals that separate
the two initializations and the object
instantiation in the above output.

Tested using SDK 1.4.1 under WinXP
************************************************/
import java.util.Date;

public class Init01{
  public static void main(String[] args){
  	//Display start load time
  	System.out.println("Start load: " + 
  	                                 new Date());
    //Force the class named A to load using a
    // class literal.
    Class aClass = A.class;
    
    //Alterntive way to cause the class named A
    // to load.
    //try{
      //Class aClass = Class.forName("A");  
    //}catch(ClassNotFoundException e){
    // 	                    e.printStackTrace();}
    //Display end load time
    System.out.println("End load: " + 
                                     new Date());
    
    //Sleep for five seconds after the class
    // loads
    try{
      Thread.currentThread().sleep(5000);
    }catch(Exception e){System.out.println(e);}
    
    //Instantiate a new object of the class named
    // A and display the data stored in the
    // variables.
    new A().showData();
  }//end main
}//end class Init01
//=============================================//

class A{
  //Declare six static variables and initialize
  // some of them when they are declared.  The
  // others will be automatically initialized to
  // either zero or null, but this may change
  // later due to the code in static intializer
  // blocks.
  static int var1 = 6;
  static int var2 = 9;
  static int var3;//originally initialized to 0
  static long var4;//originally initialized to 0

  static Date date1;//initialized to null
  static Date date2;//initialized to null

  //Declare an instance variable which is
  // originally initialized to null.
  Date date3;

  static{
    //First static initializer block records the
    // time and then executes a loop to
    // compute a new initial value for var3.
    date1 = new Date();
    for(int cnt = 0; cnt < var2; cnt++){
      var3 += var1;
    }//end for loop
    System.out.println("End first static init: "
                                   + new Date());
  }//end first static initializer block
  //-------------------------------------------//

  //Note that the constructor and an instance
  // method physically separate the two static
  // initializer blocks.
  A(){//constructor
    //Record the time in an instance variable.
    date3 = new Date();
  }//end constructor
  //-------------------------------------------//

  void showData(){//an instance method
    //Display the times that the variables were
    // initialized along with the values stored
    // in those variables.
    System.out.println("var3 initialized: "
                                        + date1);
    System.out.println("var3 = " + var3);
    System.out.println("var4 initialized: "
                                        + date2);
    System.out.println("var4 = " + var4
                                      + " msec");
    System.out.println("Obj instantiated: "
                                        + date3);
  }//end showData
  //-------------------------------------------//

  static{
    //Second static initializer block sleeps for
    // five seconds, records the time, and then
    // computes a new intial value for var4 based
    // on values recorded during previous
    // initialization operations.
    try{
      //Sleep for five seconds
      Thread.currentThread().sleep(5000);
    }catch(Exception e){System.out.println(e);}
    date2 = new Date();
    var4 = date2.getTime() - date1.getTime();
    System.out.println("End second static init: "
                                   + new Date());
  }//end second static initializer block
}//end class A