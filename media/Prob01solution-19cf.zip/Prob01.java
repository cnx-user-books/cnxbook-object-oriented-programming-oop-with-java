//34567890123456789012345678901234567890123456789012345678
/*File Prob01 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class Prob01{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Picture[] pictures = new Prob01Runner().run();
    System.out.println(pictures[0]);
    System.out.println(pictures[1]);
    System.out.println(pictures[2]);
  }//end main method
}//end class Prob01
//End program specifications.
//////////////////////////////////////////////////////////

class Prob01Runner{

  public Prob01Runner(){//constructor
    System.out.println("Dick Baldwin.");
  }//end constructor
  //----------------------------------------------------//
  public Picture[] run(){
    //Insert executable code here
    Picture picA = new Picture("Prob01a.jpg");
    picA.explore();
    Picture picB = new Picture("Prob01b.jpg");
    picB.addMessage("Dick Baldwin.",10,20);
    picB.explore();

    Picture picC = cropAndFlip(picA,4,5,80,105);
    copyPictureWithCrop(picC,picB,122,70);

    picB.show();

    Picture[] output = {picA,picB,picC};
    return output;
  }//end run
  //----------------------------------------------------//

  //Crops a picture to the specified coordinate values and
  // flips it around a vertical line at its center.
  //Also makes it partially transparent
  private Picture cropAndFlip(
                 Picture pic,int x1,int y1,int x2,int y2){
    Picture output = new Picture(x2-x1+1,y2-y1+1);

    int width = output.getWidth();
    Pixel pixel = null;
    Color color = null;
    for(int col = x1;col < (x2+1);col++){
      for(int row = y1;row < (y2+1);row++){
        color = pic.getPixel(col,row).getColor();
        pixel = output.getPixel(width-col+x1-1,row-y1);
        pixel.setColor(color);
      }//end inner loop
    }//end outer loop

    width = output.getWidth();
    int height = output.getHeight();
    pixel = null;
    color = null;
    for(int col = 0;col < width;col++){
      for(int row = 0;row < height;row++){

        int basicPixel = output.getBasicPixel(col,row);
        basicPixel = basicPixel & 0x00FFFFFF;
        basicPixel = basicPixel | 0x5F000000;
        output.setBasicPixel(col,row,basicPixel);
      }//end inner loop
    }//end outer loop


    return output;
  }//end crop and flip
  //----------------------------------------------------//

  //Copies the source picture onto the destination
  // picture with an offset on both axes.
  private void copyPictureWithCrop(
           Picture source,Picture dest,int xOff,
                                       int yOff){

      Graphics destGraphics = dest.getGraphics();
      Image sourceImage = source.getImage();
      destGraphics.drawImage(sourceImage,
                             xOff,
                             yOff,
                             null);
  }//end copyPictureWithCrop method
}//end class Prob01Runner



//34567890123456789012345678901234567890123456789012345678