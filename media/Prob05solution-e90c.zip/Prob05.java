//34567890123456789012345678901234567890123456789012345678
/*File Prob05 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.geom.AffineTransform;
import java.awt.Graphics2D;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class Prob05{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob05Runner();
  }//end main method
}//end class Prob05
//End program specifications.
//////////////////////////////////////////////////////////

class Prob05Runner extends JFrame{

  private JPanel mainPanel = new JPanel();
  private JPanel titlePanel = new JPanel();
  private JSlider slider = new JSlider(-360,360,0);

  private Picture butterfly = new Picture("Prob05.jpg");
  private Picture background = null;

  private int butterflyWidth = butterfly.getWidth();
  private int butterflyHeight = butterfly.getHeight();

  private Picture display = null;
  private int displayWidth = 0;
  private int displayHeight = 0;

  private Image image = null;
  private Graphics graphics = null;
  private AffineTransform rotateTransform = null;
  private AffineTransform translateTransform = null;
  private Graphics2D g2 = null;

  public Prob05Runner(){//constructor

    System.out.println("Dick Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Compute the minimum dimensions allowed for the
    // display window that will contain the butterfly
    // image rotated at any angle. This turns out to
    // be a square with the length of each side equal
    // to the diagonal length of the butterfly picture.
    //The length of each side was increased by one
    // pixel to guard against loss of precision when
    // converting from double to int.
    int diagonal = 1 + (int)(Math.sqrt(
                        butterflyWidth*butterflyWidth +
                        butterflyHeight*butterflyHeight));

    //Instantiate the picture in which the rotated
    // butterfly image will be displayed.
    display = new Picture(diagonal,diagonal);
    displayWidth = displayHeight = diagonal;

    //This picture provides a white background the same
    // size as the display picture.
    background = new Picture(diagonal,diagonal);

    butterfly.addMessage("Dick Baldwin",10,20);

    //Construct the GUI for the slider.
    slider.setMajorTickSpacing(60);
    slider.setMinorTickSpacing(30);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    mainPanel.setLayout(new BorderLayout());
    titlePanel.add(new JLabel(
                            "Rotation Angle in Degrees"));
    mainPanel.add(titlePanel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    getContentPane().add(mainPanel);
    //pack();
    setSize(displayWidth + 7,97);
    setTitle("Dick Baldwin");
    setLocation(0,displayHeight + 25);
    setVisible(true);

    //Place the butterfly image in the display picture
    // with zero degrees rotation.
    rotatePicture(0);

    display.show();
    //--------------------------------------------------//
    //Register an anonymous listener object on the slider.
    //Each time the slider fires a ChangeEvent, this event
    // handler restores the background image of the
    // display. Then it draws a rotated version of the
    // butterfly on top of the background image using the
    // slider value, which ranges from -360 to +360, as
    // the rotation angle in degrees. The image of the
    // butterfly is always centered in the display
    // picture.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Restore the background image of the display
          // to all white.
          graphics = display.getGraphics();
          graphics.drawImage(
                          background.getImage(),0,0,null);
          //Rotate the butterfly image, draw it on the
          // display, and repaint the display on the
          // screen..
          rotatePicture(slider.getValue());
          display.repaint();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//
  //This method accepts a rotation angle in degrees. It
  // rotates a butterfly image by that angle around its
  // center, translates, and draws the rotated image in
  // the center of a display picture.
  private void rotatePicture(double angle){

    //Set up the rotation transform
    rotateTransform = new AffineTransform();
    rotateTransform.rotate(Math.toRadians(angle),
                           butterflyWidth/2,
                           butterflyHeight/2);

    //Set up the translation transform that will translate
    // the rotated image to the center of the new Picture
    // object.
    translateTransform = new AffineTransform();
    translateTransform.translate(
                     (displayWidth - butterflyWidth)/2,
                     (displayHeight - butterflyHeight)/2);

    //Concatenate the two transforms so that the image
    // will first be rotated around its center and then
    // translated to the center of the new Picture object.
    translateTransform.concatenate(rotateTransform);

    //Get the graphics context of the display picture,
    // apply the transform to the butterfly image, and
    // draw the transformed picture on the display
    // picture.
    Graphics2D g2 = (Graphics2D)display.getGraphics();
    g2.drawImage(butterfly.getImage(),
                 translateTransform,
                 null);

  }//end rotatePicture

}//end class Prob05Runner



//34567890123456789012345678901234567890123456789012345678
