import java.awt.*;
import java.awt.geom.*;

/* Classes in this graphics library were derived from classes 
 * in a multimedia library published by Barb Ericson at 
 * http://home.cc.gatech.edu/TeaParty/47 in a downloadable 
 * file named bookClasses-3-9-10-with-doc.zip. 
 * A statement on that page reads as follows: 
 * "The source code in bookClasses is licensed under a
 * Creative Commons Attribution 3.0 United 
 * States License."
 */

/**
 * This class represents a displayable path segment
 * it has a color, width, and a Line2D object
 * Copyright Georgia Institute of Technology 2005. Published
 * under a Creative Commons Attribution 3.0 United States
 * License and modified by R.G.Baldwin.
 * @author Barb Ericson ericson@cc.gatech.edu
 */ 
public class PathSegment
{
  //////////////// fields /////////////////////
  private Color color;
  private int width;
  private Line2D.Float line;
  
  //////////////// constructors ///////////////
  
  /**
   * Constructor that takes the color, width, 
   * and line
   * @param theColor the incoming Color object
   * @param theWidth the incoming width
   * @param theLine the incoming line
   */
  public PathSegment (Color theColor, int theWidth,
                      Line2D.Float theLine)
  {
    this.color = theColor;
    this.width = theWidth;
    this.line = theLine;
  }
  
  //////////////// methods ////////////////////
  
  /**
   * Method to paint this path segment
   * @param g the graphics context
   */
  public void paintComponent(Graphics g)
  {
    Graphics2D g2 = (Graphics2D) g;
    BasicStroke penStroke = new BasicStroke(this.width); 
    g2.setStroke(penStroke);
    g2.setColor(this.color);
    g2.draw(this.line);
  }
  
} // end of class