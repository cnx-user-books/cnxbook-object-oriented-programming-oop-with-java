import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observer;
import java.awt.*;

/* Classes in this graphics library were derived from classes 
 * in a multimedia library published by Barb Ericson at 
 * http://home.cc.gatech.edu/TeaParty/47 in a downloadable 
 * file named bookClasses-3-9-10-with-doc.zip. 
 * A statement on that page reads as follows: 
 * "The source code in bookClasses is licensed under a
 * Creative Commons Attribution 3.0 United 
 * States License."
 *
 * The original version of this class was modified as follows:
 *
 * 1. Implementation of the ModelDisplay interface was
 * eliminated. The interface was only used by the World and
 * Turtle classes among the subset of classes selected for
 * this library and was therefore considered to be superfluous
 * and confusing to students.
 *
 * 2. Added a method named getFrame that returns a reference
 * to the JFrame object from which the World is constructed.
 *
 * 3. This version of the World class was modified to make
 * it possible to specify the name of an image file when
 * the World object is instantiated. The image is used as the
 * background for the world in place of the default blank
 * white background.
 *
 * 4. Called the setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
 * method on the JFrame when the frame is initialized to cause
 * the program to terminate when the user clicks the X-button
 * in the upper-right corner of the frame.
 */

/**
 * Class to represent a 2d world that can hold turtles and
 * display them.
 * 
 * Copyright Georgia Institute of Technology 2004. Published
 * under a Creative Commons Attribution 3.0 United States
 * License and modified by R.G.Baldwin.
 *
 * @author Barb Ericson ericson@cc.gatech.edu
 */
//public class World extends JComponent implements ModelDisplay
public class World extends JComponent
{
  ////////////////// fields ///////////////////////
  
  /** should automatically repaint when model changed */
  private boolean autoRepaint = true;
  
  /** the background color for the world */
  private Color background = Color.white;
  
  /** the width of the world */
  private int width = 640;
  
  /** the height of the world */
  private int height = 480;
  
  /** the list of turtles in the world */
  private List<Turtle> turtleList = new ArrayList<Turtle>();
  
  /** the JFrame to show this world in */
  private JFrame frame = new JFrame("World");
  
  /** background picture */
  private Picture picture = null;
  
  ////////////////// the constructors ///////////////

  private String fileName = null;
  /**
   *New constructor that accepts the name of an image
   * file as a String. The image file is ultimately used
   * as the background image for the World object.
   *@param fileName Name of an image file to use as a 
   *background image.
   */
  public World(String fileName){
    this.fileName = fileName;
    initWorld(true);
  }//end constructor
  
  /**
   * Constructor that takes no arguments
   */
  public World()
  {
    // set up the world and make it visible
    initWorld(true);
  }
  
  /**
   * Constructor that takes a boolean to
   * say if this world should be visible
   * or not
   * @param visibleFlag if true will be visible
   * else if false will not be visible
   */
  public World(boolean visibleFlag)
  {
    initWorld(visibleFlag);
  }
  
  /**
   * Constructor that takes a width and height for this
   * world
   * @param w the width for the world
   * @param h the height for the world
   */
  public World(int w, int h)
  {
    width = w;
    height = h;
    
    // set up the world and make it visible
    initWorld(true);
  }
    
  ///////////////// methods ///////////////////////////
  
   /**
   *Method to return a reference to the JFrame.
   *@return A reference to the JFrame object containing
   *the world.
   */
   public JFrame getFrame(){
     return frame;
   }//end getFrame
    
  /**
   * Method to initialize the world
   * @param visibleFlag the flag to make the world
   * visible or not
   */
  private void initWorld(boolean visibleFlag)
  {
    //Modifications to deal with the image file.
    // create the background picture
    if(fileName == null){
      picture = new Picture(width,height);
    }else{
      picture = new Picture(fileName);
      width = picture.getWidth();
      height = picture.getHeight();
      picture.addMessage(fileName,10,20);
      System.out.println(picture);
    }//end else

    // set the preferred size
    this.setPreferredSize(new Dimension(width,height));

    // add this panel to the frame
    frame.getContentPane().add(this);

    // pack the frame
    frame.pack();

    // show this world
    frame.setVisible(visibleFlag);
    
    //New by Baldwin. Cause the program to terminate
    // when the user clicks the X-button in the upper-
    // right corner of the JFrame.
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
  
  /** 
   * Method to get the graphics context for drawing on
   * @return the graphics context of the background picture
   */
  public Graphics getGraphics() { return picture.getGraphics(); }
  
  /**
   * Method to clear the background picture
   */
  public void clearBackground() { picture = new Picture(width,height); }
  
  /**
   * Method to get the background picture
   * @return the background picture
   */
  public Picture getPicture() { return picture; }
  
  /**
   * Method to set the background picture
   * @param pict the background picture to use
   */
  public void setPicture(Picture pict) { picture = pict; }
  
  /**
   * Method to paint this component
   * @param g the graphics context
   */
  public synchronized void paintComponent(Graphics g)
  {
    Turtle turtle = null;
    
    // draw the background image
    g.drawImage(picture.getImage(),0,0,null);
    
    // loop drawing each turtle on the background image
    Iterator iterator = turtleList.iterator();
    while (iterator.hasNext())
    {
      turtle = (Turtle) iterator.next();
      turtle.paintComponent(g);
    } 
  }
  
  /**
   * Metod to get the last turtle in this world 
   * @return the last turtle added to this world
   */
  public Turtle getLastTurtle()
  {
    return (Turtle) turtleList.get(turtleList.size() - 1);
  }
  
  
  /**
   * Method to add a model to this model displayer
   * @param model the model object to add
   */
  public void addModel(Object model)
  {
    turtleList.add((Turtle) model);
    if (autoRepaint)
       repaint();
  }
  
  /**
   * Method to check if this world contains the passed
   * turtle
   * @param turtle the incoming Turtle object
   * @return true if there else false
   */
  public boolean containsTurtle(Turtle turtle)
  {
    return (turtleList.contains(turtle));
  }
  
  /**
   * Method to remove the passed object from the world
   * @param model the model object to remove
   */
  public void remove(Object model)
  {
    turtleList.remove(model);
  }
  
  /**
   * Method to get the width in pixels
   * @return the width in pixels
   */
  public int getWidth() { return width; }
  
  /**
   * Method to get the height in pixels
   * @return the height in pixels
   */
  public int getHeight() { return height; }
  
  /**
   * Method that allows the model to notify the display
   */
  public void modelChanged()
  {
    if (autoRepaint)
       repaint();
  }
  
  /**
   * Method to set the automatically repaint flag
   * @param value if true will auto repaint 
   */
  public void setAutoRepaint(boolean value) { autoRepaint = value; }
  
  /**
   * Method to hide the frame
   */
//  public void hide() 
//  {
//    frame.setVisible(false);
//  }
  
  /**
   * Method to show the frame
   */
//  public void show()
//  {
//    frame.setVisible(true);
//  }
  
  /**
   * Method to set the visibility of the world 
   * @param value a boolean value to say if should show or hide
   */
  public void setVisible(boolean value)
  {
    frame.setVisible(value);
  }
  
  /**
   * Method to get the list of turtles in the world
   * @return a list of turtles in the world
   */
  public List getTurtleList() 
  { return turtleList;}
  
  /**
   * Method to get an iterator on the list of turtles
   * @return an iterator for the list of turtles
   */
  public Iterator getTurtleIterator()
  { return turtleList.iterator();}
  
  /**
   * Method that returns information about this world
   * in the form of a string
   * @return a string of information about this world
   */
  public String toString() 
  {
    return "A " + getWidth() + " by " + getHeight() + 
      " world with " + turtleList.size() + " turtles in it.";
  }
  
} // end of World class