//34567890123456789012345678901234567890123456789012345678
/*File Prob04 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Toolkit;

public class Prob04{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob04Runner();
  }//end main method
}//end class Prob04
//End program specifications.
//////////////////////////////////////////////////////////

class Prob04Runner{
  Turtle turtle = null;
  Picture picture = null;
  int counter = 0;
  World world = new World(200,200);
  JButton button = new JButton("Click Me.");

  public Prob04Runner(){
    System.out.println("Dick Baldwin");
    System.out.println(world.getPicture());

    //Get a reference to the JFrame object that is used
    // to display the World.
    JFrame frame = world.getFrame();

    //Add the JButton object to the
    // SOUTH location in the JFrame object.
    frame.getContentPane().add(button,BorderLayout.SOUTH);

    frame.pack();

    //Use an anonymous class to register an action
    // listener on the button. Note that the student is
    // not required to use an anonymous class.
    button.addActionListener(new ActionListener()
      {//Begin the class definition
        public void actionPerformed(ActionEvent e){
          picture = world.getPicture();

          //Set picture background to blue.
          picture.setAllPixelsToAColor(Color.GREEN);
          picture.setMessageColor(Color.BLUE);
          //Display the student's name on the picture.
          picture.addMessage(
                         "Dick Baldwin",10,20);
          //Add a turtle to the world. This causes the
          // world to be repainted.
          if(turtle == null){
            turtle = new Turtle(150,150,world);
            turtle.setHeading(90);
            turtle.setShellColor(Color.RED);
            turtle.setBodyColor(Color.BLUE);
          }else{
            turtle.turnLeft();
            turtle.forward(100+counter);
            if(counter++ %2 != 0){
              picture.setAllPixelsToAColor(Color.GREEN);
              picture.setMessageColor(Color.BLUE);
              picture.addMessage(
                         "Dick Baldwin",10,20);
              turtle.setShellColor(Color.RED);
              turtle.setBodyColor(Color.BLUE);
            }else{
              picture.setAllPixelsToAColor(Color.YELLOW);
              picture.setMessageColor(Color.RED);
              picture.addMessage(
                         "Dick Baldwin",10,20);
              turtle.setShellColor(Color.BLUE);
              turtle.setBodyColor(Color.RED);
            }//end else
            picture.addMessage(
                         "Dick Baldwin",10,20);
          }//end else
        }//end actionPerformed
      }//end class definition
    );//end addActionListener

  }//end constructor
  //----------------------------------------------------//

}//end class Prob04Runner
//34567890123456789012345678901234567890123456789012345678
