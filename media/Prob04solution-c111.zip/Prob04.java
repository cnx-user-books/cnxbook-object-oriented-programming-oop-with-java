//34567890123456789012345678901234567890123456789012345678
/*File Prob04 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.geom.AffineTransform;
import java.awt.Graphics2D;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class Prob04{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob04Runner();
  }//end main method
}//end class Prob04
//End program specifications.
//////////////////////////////////////////////////////////

class Prob04Runner extends JFrame{

  private JPanel mainPanel = new JPanel();
  private JPanel titlePanel = new JPanel();
  private JSlider slider = new JSlider(0,100,0);

  private Picture beach = new Picture("Prob04a.jpg");
  private Picture butterfly = new Picture("Prob04b.jpg");

  private int beachWidth = beach.getWidth();
  private int beachHeight = beach.getHeight();

  private Picture display =
            new Picture(beachWidth,beachHeight);

  private Image image = null;
  private Graphics graphics = null;
  private AffineTransform transform = null;
  private Graphics2D g2 = null;

  public Prob04Runner(){//constructor

    System.out.println("Dick Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    beach.addMessage("Dick Baldwin",10,20);
    butterfly.addMessage("Dick Baldwin",10,20);

    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    mainPanel.setLayout(new BorderLayout());
    titlePanel.add(new JLabel(
                          "Percent Size of Beach Image"));
    mainPanel.add(titlePanel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    getContentPane().add(mainPanel);
    //pack();
    setSize(beachWidth + 7,97);
    setTitle("Dick Baldwin");
    setLocation(0,beachHeight + 25);
    setVisible(true);

    //Draw and display the background image of the
    // butterfly.
    graphics = display.getGraphics();
    graphics.drawImage(butterfly.getImage(),0,0,null);

    display.show();
    //--------------------------------------------------//
    //Register an anonymous listener object on the slider.
    //Each time the slider fires a ChangeEvent, this event
    // handler restores the background image of the
    // butterfly. Then it draws a scaled version of the
    // beach on top of the background image using the
    // slider value, which ranges from 0 to 100 as the
    // scale factor as a percent of 1.0. The image of the
    // beach is always aligned with the upper-left corner
    // of the contentPane of the JFrame.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){

          //Restore the background image of the butterfly.
          graphics = display.getGraphics();
          graphics.drawImage(
                          butterfly.getImage(),0,0,null);

          drawScaledPictureOnPicture(beach,
                                     display,
                                     slider.getValue());
          display.repaint();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//

  //Scales and draws the source picture onto the upper
  // left corner of the destination picture.
  private void drawScaledPictureOnPicture(
                                      Picture source,
                                      Picture dest,
                                      double scaleFactor){

    transform = new AffineTransform();
    transform.scale(scaleFactor/100.0,scaleFactor/100.0);

    //Get the Graphics2D object used to draw on the
    // destination picture.
    g2 = (Graphics2D)dest.getGraphics();

    //Scale and draw the source image on the destination
    // image.
    g2.drawImage(source.getImage(),transform,null);

  }//end drawScaledPictureOnPicture method
}//end class Prob04Runner



//34567890123456789012345678901234567890123456789012345678
