//34567890123456789012345678901234567890123456789012345678

/*File Prob01 Copyright 2012 R.G.Baldwin
*********************************************************/

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.WindowConstants;

public class Prob01{
  public static void main(String[] args){
    new Prob01Runner();
  }//end main method
}//end class Prob01
//======================================================//

class Prob01Runner extends JFrame{
  private Prob01Runner jFrameObj = null;
  private PictureExplorer explorer = null;
  private Picture pix;

  private JPanel fileNamePanel = new JPanel();
  private JTextField inputFileNameField =
                         new JTextField("Prob01a.jpg",20);

  private String fileName = "no file specified";
  //----------------------------------------------------//

  public Prob01Runner(){//constructor
    fileNamePanel.add(new JLabel("File name: "));
    fileNamePanel.add(inputFileNameField);

    //Add the fileNamePanel to the content pane, adjust
    // to the correct size, and set the title.
    getContentPane().add(fileNamePanel);
    pack();
    setTitle("Dick Baldwin");

    //Make the GUI visible, set the focus, and establish
    // a reference to the GUI object.
    setVisible(true);
    inputFileNameField.requestFocus();
    jFrameObj = this;

    //--------------------------------------------------//
    //Register listeners on the user input field.
    //--------------------------------------------------//

    inputFileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          fileName = inputFileNameField.getText();

          pix = new Picture(fileName);
          pix.addMessage("Dick Baldwin",10,20);
          
          //Invert the color components for every pixel
          // in the picture.
          Pixel[] pixelArray = pix.getPixels();
          for(Pixel pixel:pixelArray ){
            pixel.setBlue(255 - pixel.getBlue());
            pixel.setGreen(255 - pixel.getGreen());
            pixel.setRed(255 - pixel.getRed());
          }//end for loop

          explorer = new PictureExplorer(pix);

          //Set the location for the control GUI
          // immediately below the PictureExplorer object,
          // and set its default close operation.
          setLocation(0,pix.getHeight() + 128);
          jFrameObj.setDefaultCloseOperation(
                           WindowConstants.EXIT_ON_CLOSE);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//
}//end class Prob01Runner


//34567890123456789012345678901234567890123456789012345678
