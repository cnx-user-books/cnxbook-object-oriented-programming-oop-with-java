//34567890123456789012345678901234567890123456789012345678
/*File Prob05 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Dimension;
import javax.swing.JColorChooser;

public class Prob05{
  public static void main(String[] args){
    new Prob05Runner();
  }//end main method
}//end class Prob05
//======================================================//

class Prob05Runner extends JFrame{
  private Prob05Runner jFrameObj = null;
  private PictureExplorer explorer = null;
  private Picture pix;
  private JFrame explorerFrame;
  
  private JPanel controlPanel = new JPanel();
  private JPanel colorPanel = new JPanel();
  private JPanel buttonPanel = new JPanel();
  private JPanel colorIndicatorPanel = new JPanel();

  private JTextField redField = new JTextField("000000");
  private JTextField greenField = 
                                 new JTextField("000000");
  private JTextField blueField = new JTextField("000000");
  
  private int redInt = 0;
  private int greenInt = 0;
  private int blueInt = 0;
  
  //Copies of properties of the PictureExplorer object
  private int xIndex = 0;
  private int yIndex = 0;
  private double zoomFactor = 0;

  private JButton updateButton = 
                        new JButton("Update Pixel Color");
  //----------------------------------------------------//

  public Prob05Runner(){//constructor

    pix = new Picture("Prob05.jpg");
    pix.addMessage("Dick Baldwin",10,20);
    explorer = new PictureExplorer(pix);
    explorerFrame = explorer.getFrame();
    explorerFrame.setDefaultCloseOperation(
               WindowConstants.DO_NOTHING_ON_CLOSE);

    //Set the location for the control GUI
    // immediately below the PictureExplorer object,
    // and set its default close operation.
    setLocation(0,pix.getHeight() + 128);

    setDefaultCloseOperation(
                           WindowConstants.EXIT_ON_CLOSE);

    controlPanel.setLayout(new GridLayout(2,1));
    controlPanel.add(colorPanel);
    controlPanel.add(buttonPanel);

    colorPanel.setBackground(Color.GREEN);
    colorPanel.add(new JLabel("Red = "));
    colorPanel.add(redField);
    colorPanel.add(new JLabel(" Green = "));
    colorPanel.add(greenField);
    colorPanel.add(new JLabel(" Blue = "));
    colorPanel.add(blueField);
    colorPanel.add(colorIndicatorPanel);

    colorIndicatorPanel.setBorder(
                           new LineBorder(Color.black,1));
    colorIndicatorPanel.setPreferredSize(
                                    new Dimension(20,20));

    buttonPanel.setBackground(Color.BLUE);
    buttonPanel.add(updateButton);
    
    //Color the swatch for the first time.
    paintColorSwatch();

    //Add the controlPanel to the content pane, adjust to
    // the correct size, and set the tiele.
    getContentPane().add(controlPanel);
    pack();
    setTitle("Dick Baldwin");

    //Make the GUI visible
    setVisible(true);

    //--------------------------------------------------//
    //Register listeners on the user input components.
    //--------------------------------------------------//
    updateButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){

          //Get properties of PictureExplorer object.
          xIndex = explorer.getXIndex();
          yIndex = explorer.getYIndex();
          zoomFactor = explorer.getZoomFactor();
          
          //Save zoom factor as a string.
          String zoomString = "100%";
          if(zoomFactor == 0.25){
            zoomString = "25%";
          }else if(zoomFactor == 0.50){
            zoomString = "50%";
          }else if(zoomFactor == 0.75){
            zoomString = "75%";
          }else if(zoomFactor == 1.0){
            zoomString = "100%";
          }else if(zoomFactor == 1.5){
            zoomString = "150%";
          }else if(zoomFactor == 2.0){
            zoomString = "200%";
          }else if(zoomFactor == 5.0){
            zoomString = "500%";
          }else{
            zoomString = "100%";//in case no match
          }//end else

          Color newColor = new Color(
                                 redInt,greenInt,blueInt);
          pix.getPixel(xIndex,yIndex).setColor(newColor);

          //Dispose of the existing explorer and create a
          // new one.
          explorerFrame.dispose();

          explorer = new PictureExplorer(pix);
          //Get reference to the new frame
          explorerFrame = explorer.getFrame();
          explorerFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

          //Now set the state of the new explorer.
          //Simulate a mouse pressed event in the picture
          // to set the cursor and the text in the
          // coordinate fields.
          explorer.mousePressed(new MouseEvent(
                           new JButton("dummy component"),
                           MouseEvent.MOUSE_PRESSED,
                           (long)0,
                           0,
                           xIndex,
                           yIndex,
                           0,
                           false));

          //Simulate an action event on the zoom menu to
          // set the zoom.
          explorer.actionPerformed(new ActionEvent(
                             explorer,
                             ActionEvent.ACTION_PERFORMED,
                             zoomString));


        }//end actionPerformed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a document listener on the red text field.
    // This listener will respond when the contents of
    // the text field are modified either by the program
    // or by the user.
    redField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){
          //Empty method - not needed
        }//end changedUpdate

        public void removeUpdate(DocumentEvent e){
          try{
            redInt = Integer.parseInt(
                                   redField.getText());
            if((redInt >= 0) && (redInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            redInt = Integer.parseInt(
                                   redField.getText());
            if((redInt >= 0) && (redInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//

    //Register a document listener on the green text
    // field. Essentially the same as the above.
    greenField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            greenInt = Integer.parseInt(
                                 greenField.getText());
            if((greenInt >= 0) && (greenInt <= 255))
            {
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            greenInt = Integer.parseInt(
                                 greenField.getText());
            if((greenInt >= 0) && (greenInt <= 255))
            {
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
    
    //Register a document listener on the blue text
    // field. Essentially the same as the above.
    blueField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            blueInt = Integer.parseInt(
                                  blueField.getText());
            if((blueInt >= 0) && (blueInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            blueInt = Integer.parseInt(
                                  blueField.getText());
            if((blueInt >= 0) && (blueInt <= 255)){
              paintColorSwatch();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to color a swatch 
  // located next to the RGB color values.
  private void paintColorSwatch(){
    colorIndicatorPanel.setBackground(
                      new Color(redInt,greenInt,blueInt));
  }//end paintColorSwatch

  //----------------------------------------------------//

  //The purpose of this method is to absorb any exceptions
  // that may be thrown by the parseInt method in order
  // to avoid having the program abort. In the event that
  // an exception is thrown, this method simply returns an
  // int value of 0;
  private int goParseInt(String string){
    int result = 0;
    try{
      result = Integer.parseInt(string);
    }catch(Exception e){
      result = 0;
    }//end catch
    return result;
  }//end goParseInt

  //----------------------------------------------------//


}//end class Prob05Runner


//34567890123456789012345678901234567890123456789012345678
