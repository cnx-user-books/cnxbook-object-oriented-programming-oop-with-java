//34567890123456789012345678901234567890123456789012345678
/*File Prob03 Copyright 2012 R.G.Baldwin
*********************************************************/
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Prob03{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Prob03Runner().run();
  }//end main method
}//end class Prob03
//End program specifications.
//////////////////////////////////////////////////////////

class Prob03Runner{
  public Prob03Runner(){
    System.out.println("Dick Baldwin");
  }//end constructor
  //----------------------------------------------------//
  public void run(){
    //This reference must be final because it is
    // referenced from within an anonymous class
    // definition.
    final World world = new World(200,300);

    //Get a reference to the JFrame object that is used
    // to display the World.
    JFrame frame = world.getFrame();

    //Instantiate a new JButton object and add it to the
    // SOUTH location in the JFrame object.
    JButton button = new JButton(
                               "Click to make a turtle.");
    frame.getContentPane().add(button,BorderLayout.SOUTH);


    frame.pack();


    //Use an anonymous class to register an action
    // listener on the button. Note that the student is
    // not required to use an anonymous class.
    button.addActionListener(new ActionListener()
      {//Begin the class definition
        public void actionPerformed(ActionEvent e){
          Picture picture = world.getPicture();
          System.out.println(picture);
          //Set picture background to blue.
          picture.setAllPixelsToAColor(Color.BLUE);
          //Display the student's name on the picture.
          picture.addMessage(
                         "Dick Baldwin",10,20);
          //Add a turtle to the world. This causes the
          // world to be repainted.
          Turtle turtle = new Turtle(world);
        }//end actionPerformed
      }//end class definition
    );//end addActionListener

  }//end run
  //----------------------------------------------------//
}//end class Prob03Runner
//34567890123456789012345678901234567890123456789012345678
