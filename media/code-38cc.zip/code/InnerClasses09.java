//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//

/*InnerClasses09.java
Copyright 2003, R.G.Baldwin
Revised 08/26/03

Illustrates static top-level classes that extend
their containing class.

An abstract class named Shape is defined, which
contains two static top-level classes named
Rectangle and Circle.

Rectangle and Circle each extend Shape.

Shape declares an abstract method named area(),
which is overridden in each of the static
top-level classes contained within the
definition of Shape.

Each of the overridden methods contains the
appropriate code to calculate and display the
area of a Shape object of that particular
subclass type (Rectangle or Circle).

An object is instantiated from each of the
static top-level classes.  That object's
reference is saved as type Shape.

The area() method is invoked on each of the
references.  Polymorphic behavior causes the
appropriate overridden version of the area()
method to be invoked in each case, causing the
correct area for each type of shape to be
displayed.

The output from the program is:

Rectangle area = 6
Circle area = 28.274333882308138

Compilation of the program produces the following
class files:

InnerClasses09.class
Shape$Circle.class
Shape$Rectangle.class
Shape.class

Tested using JDK 1.4.2 under Win XP
************************************************/

//This class contains two nested static
// top-level classes. I made this class package-
// private instead of public so that I could
// contain everything in a single source file.
abstract class Shape{
  //This abstract method is overridden in each
  // of the nested classes
  public abstract void area();

  //-------------------------------------------//
  //The definitions of two nested top-level
  // classes follow

  //Nested top-level class named Rectangle
  public static class Rectangle extends Shape{
    int length;
    int width;

    public Rectangle(int length,int width){
      this.length = length;
      this.width = width;
    }//end constructor

    public void area(){//override the area method
      System.out.println(
             "Rectangle area = " + length*width);
    }//end overridden area() method
  }//end class Rectangle

  //Nested top-level class named Circle
  public static class Circle extends Shape{
   int radius;

   public Circle(int radius){
     this.radius = radius;
   }//end constructor

    public void area(){//override the area method
      System.out.println("Circle area = "
                    + Math.PI * radius * radius);
    }//end overridden area() method
  }//end class Circle

}//end class Shape

//=============================================//
//This controlling class instantiates and
// processes an object from each of the nested
// top-level classes defined above.
public class InnerClasses09{
  public static void main(String[] args){

    //Instantiate and process an object of the
    // class named Shape.Rectangle.  Save the
    // object's reference as the superclass
    // type Shape.
    Shape aShape = new Shape.Rectangle(2,3);
    aShape.area();//Get and display the area

    //Instantiate and process an object of the
    // class named Shape.Circle.  Save the
    // object's reference as the superclass
    // type Shape.
    aShape = new Shape.Circle(3);
    aShape.area();//Get and display the area
  }//end main

}//end controlling class InnerClasses09
//=============================================//
