//34567890123456789012345678901234567890123456789012345678
/*File Prob02 Copyright 2012 R.G.Baldwin

*********************************************************/

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.Color;


public class Prob02{
  public static void main(String[] args){
    new Prob02Runner();
  }//end main method
}//end class Prob02
//======================================================//

class Prob02Runner extends JFrame{
  private JFrame explorerFrame = null;
  private PictureExplorer explorer = null;
  private Picture pix;

  private JPanel controlPanel = new JPanel();
  private JPanel colorPanel = new JPanel();
  private JPanel buttonPanel = new JPanel();

  private JTextField greenField = 
                                 new JTextField("000000");

  private JButton getDataButton = new JButton(
                     "Get and Display Green Color Value");
  private String fileName = "Prob02.jpg";
  //----------------------------------------------------//

  public Prob02Runner(){//constructor

    controlPanel.setLayout(new GridLayout(2,1));
    controlPanel.add(colorPanel);
    controlPanel.add(buttonPanel);

    colorPanel.setBackground(Color.RED);
    colorPanel.add(new JLabel(
                        "Green pixel Color at Cursor: "));
    colorPanel.add(greenField);

    buttonPanel.setBackground(Color.BLUE);
    buttonPanel.add(getDataButton);

    getContentPane().add(controlPanel);
    setTitle("Dick Baldwin");

    setVisible(true);
    
    //Create a Picture object and add a name to
    // the picture before using it to construct the
    // PictureExplorer object.
    pix = new Picture(fileName);
    pix.addMessage("Dick Baldwin",10,20);

    //Create a PictureExplorer object containing the
    // picture and set its default close operation.
    explorer = new PictureExplorer(pix);
    //Get a ref to the JFrame in the PictureExplorer
    // object.
    explorerFrame = explorer.getFrame();
    explorerFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);
    
    //Set the size of the control GUI.
    setSize(explorerFrame.getWidth(),110);

    //Set the location for the control GUI immediately
    // below the PictureExplorer object, and set its
    // default close operation.
    setLocation(0,explorerFrame.getHeight());
    setDefaultCloseOperation(
                           WindowConstants.EXIT_ON_CLOSE);

    //--------------------------------------------------//
    //Register a listener object on the button.
    //--------------------------------------------------//
    getDataButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){

//          greenField.setText(explorer.getRValue());
          greenField.setText(explorer.getGValue());

        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

  }//end constructor
}//end class Prob02Runner


//34567890123456789012345678901234567890123456789012345678
